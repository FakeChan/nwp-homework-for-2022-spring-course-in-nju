function bar=hat_yy(a,b)
    bar2=hat_xx(a',b');
    bar=bar2';
end