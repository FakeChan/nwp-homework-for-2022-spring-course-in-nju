function [E,G,H]=dt(u,v,z)
    global g
    global m
    global f
    global n
    f_wave=f+u.*haty_single(m)-v.*haty_single(m);
    E=-m.*(hat_xx(u,u)+hat_yy(v,u)+g*hatx_single(z))+f_wave.*v;
    G=-m.*(hat_xx(u,v)+hat_yy(v,v)+g*haty_single(z))-f_wave.*u;
    H=-(m.^2).*(hat_xx(u,z./m)+hat_yy(v,z./m)+(z./m).*(hatx_single(u)+haty_single(v)));
    for i=1:n(1)
        for j=1:n(2)
            if i==1 || i==n(1) || j==1 || j==n(2)
                E(i,j)=0;
                G(i,j)=0;
                H(i,j)=0;
            end
        end
    end
end