%-----------数值天气预报第六次上机作业-------------
%-------------191830035傅克成-----------------
clc;
clear all
%----读取数据----
height=readmatrix("500_0800Z29APR1973.txt")*10;
parameter=readmatrix('PARAM.txt');
z0=height;u0=z0;v0=z0;
global m
global f
global g
global n
m=parameter(1:16,:);
f=parameter(18:33,:)*10^(-4);
g=9.8;
n=size(z0);
%----设置参数----
global d
d=300000;
global t
t=10*60;
global s
s=0.5;

%----设置初始风场----
for i=1:n(1)
    if i==1
        u0(i,:)=-(m(i,:)*g./f(i,:)).*(z0(i+1,:)-z0(i,:))/d;
    elseif i==n(1)
        u0(i,:)=-(m(i,:)*g./f(i,:)).*(z0(i,:)-z0(i-1,:))/d;
    else
        u0(i,:)=-(m(i,:)*g./f(i,:)).*(z0(i+1,:)-z0(i-1,:))/(2*d);
    end
end

for j=1:n(2)
    if j==1
        v0(:,j)=(m(:,j)*g./f(:,j)).*(z0(:,j+1)-z0(:,j))/d;
    elseif j==n(2)
        v0(:,j)=(m(:,j)*g./f(:,j)).*(z0(:,j)-z0(:,j-1))/d;
    else
        v0(:,j)=(m(:,j)*g./f(:,j)).*(z0(:,j+1)-z0(:,j-1))/(2*d);
    end
end

%----计算初始变化倾向----
[E0,G0,H0]=dt(u0,v0,z0);


%----准备开始积分----
day=1;
u=zeros(n(1),n(2),day*2*12*6);v=u;z=u;E=u;G=u;H=u;
round=1;
while round<=day*2 %一天积分两轮
    step=(round-1)*72+1;
    counter=0;%时间平滑的计数器
    while step<=round*72%一轮共有72步
        %这里的step表示即将完成第x步，例如step=9表示即将完成第9步
        
        if step<=(round-1)*72+6 %欧拉后差
            if step==1
                [u(:,:,step),v(:,:,step),z(:,:,step)]=euler_back(u0,v0,z0);
            else
                [u(:,:,step),v(:,:,step),z(:,:,step)]=euler_back(u(:,:,step-1),v(:,:,step-1),z(:,:,step-1));
            end
        elseif step==(round-1)*72+7 %三步法起步
            [e2,g2,h2]=dt(u(:,:,step-1),v(:,:,step-1),z(:,:,step-1));
            u2=u(:,:,step-1)+0.5*t*e2;
            v2=v(:,:,step-1)+0.5*t*g2;
            z2=z(:,:,step-1)+0.5*t*h2;
            [e3,g3,h3]=dt(u2,v2,z2);
            u(:,:,step)=u(:,:,step-1)+t*e3;
            v(:,:,step)=v(:,:,step-1)+t*g3;
            z(:,:,step)=z(:,:,step-1)+t*h3;
        else%中央差分
            [E,G,H]=dt(u(:,:,step-1),v(:,:,step-1),z(:,:,step-1));
            [u(:,:,step),v(:,:,step),z(:,:,step)]=center(u(:,:,step-2),v(:,:,step-2),z(:,:,step-2),E,G,H);
        end
        
        %从这里开始的平滑方案,step表示完成了第x步，例如step=9表示完成了第9步
        %----时间平滑方案----
        
        if step==(round-1)*72+38
            counter=counter+1;
            if mod(counter,2)==1
                [u(:,:,step-2),v(:,:,step-2),z(:,:,step-2)]=...
                    timesmooth(u(:,:,step-3:step-1),v(:,:,step-3:step-1),z(:,:,step-3:step-1));
                [u(:,:,step-1),v(:,:,step-1),z(:,:,step-1)]=...
                    timesmooth(u(:,:,step-2:step),v(:,:,step-2:step),z(:,:,step-2:step));
                step=step-2;
            else
                step=(round-1)*72+38;
            end
            
        end
        disp(step)

        %----空间平滑方案----
        if mod(step,6)==0 && step~=round*72
            [u(:,:,step),v(:,:,step),z(:,:,step)]=smooth9(u(:,:,step),v(:,:,step),z(:,:,step));
        elseif step==round*72
            [u(:,:,step),v(:,:,step),z(:,:,step)]=smooth5(u(:,:,step),v(:,:,step),z(:,:,step));
        end

        step=step+1;
    end
    round=round+1;
end
u2=u;