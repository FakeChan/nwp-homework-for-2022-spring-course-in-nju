function [u2,v2,z2]=smooth9(u,v,z)
    global s
    global n
    u2=u;v2=v;z2=z;
    for i=2:n(1)-1
        for j=2:n(2)-1
            if i==2 || i==n(1)-1 || j==2 || j==n(2)-1
                            u2(i,j)=u(i,j)+s*(1-s)*(u(i+1,j)+u(i,j+1)+u(i-1,j)+u(i,j-1)-4*u(i,j))/2 ...
                +s^2*(u(i+1,j+1)+u(i+1,j-1)+u(i-1,j+1)+u(i-1,j-1)-4*u(i,j))/4;
                            v2(i,j)=v(i,j)+s*(1-s)*(v(i+1,j)+v(i,j+1)+v(i-1,j)+v(i,j-1)-4*v(i,j))/2 ...
                +s^2*(v(i+1,j+1)+v(i+1,j-1)+v(i-1,j+1)+v(i-1,j-1)-4*v(i,j))/4;
                            z2(i,j)=z(i,j)+s*(1-s)*(z(i+1,j)+z(i,j+1)+z(i-1,j)+z(i,j-1)-4*z(i,j))/2 ...
                +s^2*(z(i+1,j+1)+z(i+1,j-1)+z(i-1,j+1)+z(i-1,j-1)-4*z(i,j))/4;
            else
                continue
            end

        end
    end
end