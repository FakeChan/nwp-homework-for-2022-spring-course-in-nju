function bar=hatx_single(a)
    global d
    n=size(a);
    bar=zeros(n);
    for i=2:n(1)-1
        bar(i,:)=(a(i+1,:)-a(i-1,:))/(2*d);
    end
end