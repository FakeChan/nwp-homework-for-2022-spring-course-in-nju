function bar=hat_xx(a,b)
    global d
    n=size(a);
    bar=zeros(n);
    for i=2:n(1)-1
        bar(i,:)=(((a(i+1,:)+a(i,:)).*(b(i+1,:)-b(i,:)))/(2*d)+((a(i-1,:)+a(i,:)).*(b(i,:)-b(i-1,:)))/(2*d))/2;
    end
end