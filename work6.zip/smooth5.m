function [u2,v2,z2]=smooth5(u,v,z)
    global n
    global s
    u2=u;v2=v;z2=z;
    for i=2:n(1)-1
        for j=2:n(2)-1
            u2(i,j)=u(i,j)+(s/4)*(u(i+1,j)+u(i-1,j)+u(i,j+1)+u(i,j-1)-4*u(i,j));
            v2(i,j)=v(i,j)+(s/4)*(v(i+1,j)+v(i-1,j)+v(i,j+1)+v(i,j-1)-4*v(i,j));
            z2(i,j)=z(i,j)+(s/4)*(z(i+1,j)+z(i-1,j)+z(i,j+1)+z(i,j-1)-4*z(i,j));
        end
    end
end