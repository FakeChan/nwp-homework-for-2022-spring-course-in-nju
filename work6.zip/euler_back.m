function [u3,v3,z3]=euler_back(u,v,z)
    global t
    [e,g,h]=dt(u,v,z);
    u2=u+t*e;
    v2=v+t*g;
    z2=z+t*h;
    [e2,g2,h2]=dt(u2,v2,z2);
    u3=u+t*e2;
    v3=v+t*g2;
    z3=z+t*h2;
end