function bar=hatx_single(a)
    bar2=haty_single(a');
    bar=bar2';
end