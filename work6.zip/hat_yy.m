function bar=hat_yy(a,b)
    global d
    n=size(a);
    bar=zeros(n);
    for j=2:n(2)-1
        bar(:,j)=(((a(:,j+1)+a(:,j)).*(b(:,j+1)-b(:,j)))/(2*d)+((a(:,j-1)+a(:,j)).*(b(:,j)-b(:,j-1)))/(2*d))/2;
    end
end