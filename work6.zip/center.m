function [u3,v3,z3]=center(u,v,z,e,g,h)
    global t
    u3=u+2*t*e;
    v3=v+2*t*g;
    z3=z+2*t*h;
end