function bar=hat_xx(a,b)
    bar2=hat_yy(a',b');
    bar=bar2';
end