%-----------数值天气预报第六次上机作业-------------
%-------------191830035傅克成-----------------
clc;
%----读取数据----
height=readmatrix("500_0800Z29APR1973.txt")*10;
parameter=readmatrix('PARAM.txt');
global m
global f
global g
global n
m=parameter(1:16,:);
m=flip(m',2);
f=parameter(18:33,:)*10^(-4);
f=flip(f',2);
g=9.8;
z0=flip(height',2);u0=z0;v0=z0;
n=size(z0);
%----设置参数----
global d
d=300000;
global t
t=10*60;
global s
s=0.5;
day=3;

%----设置初始风场----
for i=1:n(1)
    if i==1
        v0(i,:)=(m(i,:)*g./f(i,:)).*(z0(i+1,:)-z0(i,:))/d;
    elseif i==n(1)
        v0(i,:)=(m(i,:)*g./f(i,:)).*(z0(i,:)-z0(i-1,:))/d;
    else
        v0(i,:)=(m(i,:)*g./f(i,:)).*(z0(i+1,:)-z0(i-1,:))/(2*d);
    end
end

for j=1:n(2)
    if j==1
        u0(:,j)=-(m(:,j)*g./f(:,j)).*(z0(:,j+1)-z0(:,j))/d;
    elseif j==n(2)
        u0(:,j)=-(m(:,j)*g./f(:,j)).*(z0(:,j)-z0(:,j-1))/d;
    else
        u0(:,j)=-(m(:,j)*g./f(:,j)).*(z0(:,j+1)-z0(:,j-1))/(2*d);
    end
end

%----计算初始变化倾向----
[E0,G0,H0]=dt(u0,v0,z0);


%----准备开始积分----

u=zeros(n(1),n(2),day*2*12*6);v=u;z=u;E=u;G=u;H=u;
round=1;
while round<=day*2 %一天积分两轮
    step=(round-1)*72+1;
    counter=0;%时间平滑的计数器
    while step<=round*72%一轮共有72步
        %这里的step表示即将完成第x步，例如step=9表示即将完成第9步
        
        if step<=(round-1)*72+6 %欧拉后差
            if step==1
                [u(:,:,step),v(:,:,step),z(:,:,step)]=euler_back(u0,v0,z0);
            else
                [u(:,:,step),v(:,:,step),z(:,:,step)]=euler_back(u(:,:,step-1),v(:,:,step-1),z(:,:,step-1));
            end
        elseif step==(round-1)*72+7 %三步法起步
            [e2,g2,h2]=dt(u(:,:,step-1),v(:,:,step-1),z(:,:,step-1));
            u2=u(:,:,step-1)+0.5*t*e2;
            v2=v(:,:,step-1)+0.5*t*g2;
            z2=z(:,:,step-1)+0.5*t*h2;
            [e3,g3,h3]=dt(u2,v2,z2);
            u(:,:,step)=u(:,:,step-1)+t*e3;
            v(:,:,step)=v(:,:,step-1)+t*g3;
            z(:,:,step)=z(:,:,step-1)+t*h3;
        else%中央差分
            [E,G,H]=dt(u(:,:,step-1),v(:,:,step-1),z(:,:,step-1));
            [u(:,:,step),v(:,:,step),z(:,:,step)]=center(u(:,:,step-2),v(:,:,step-2),z(:,:,step-2),E,G,H);
        end
        
        %从这里开始的平滑方案,step表示完成了第x步，例如step=9表示完成了第9步
        %----时间平滑方案----
        
        if step==(round-1)*72+38
            counter=counter+1;
            if mod(counter,2)==1
                [u(:,:,step-2),v(:,:,step-2),z(:,:,step-2)]=...
                    timesmooth(u(:,:,step-3:step-1),v(:,:,step-3:step-1),z(:,:,step-3:step-1));
                [u(:,:,step-1),v(:,:,step-1),z(:,:,step-1)]=...
                    timesmooth(u(:,:,step-2:step),v(:,:,step-2:step),z(:,:,step-2:step));
                step=step-2;
            else
                step=(round-1)*72+38;
            end
            
        end
%         disp(step)

        %----空间平滑方案----
        if mod(step,6)==0 && step~=round*72
            [u(:,:,step),v(:,:,step),z(:,:,step)]=smooth9(u(:,:,step),v(:,:,step),z(:,:,step));
        elseif step==round*72
            [u(:,:,step),v(:,:,step),z(:,:,step)]=smooth5(u(:,:,step),v(:,:,step),z(:,:,step));
        end

        step=step+1;
    end
    round=round+1;
end

%----画图----
%----计算每个网格点的经纬度----

%----参考点的信息----
r=6371000;
i_std=5;
j_std=8.5;
lon_std=90.7780;
lat_std=52.9192;
k=0.71557;
phi0=pi/6;

leq=(r*cos(phi0)/k)*((1+sin(phi0))/cos(phi0))^k;
l0=leq*(cosd(lat_std)/(1+sind(lat_std)))^k;

%计算每个点的经纬度
lat=zeros(n);lon=lat;
for i=1:n(1)
    for j=1:n(2)
        l=sqrt((i-i_std)^2*d^2+(l0-(j-j_std)*d)^2);
        a=(l/leq)^(2/k);
        lat(i,j)=asind((1-a)/(1+a));
        dx=(i-i_std)*d;
        lon(i,j)=lon_std+asind(dx/l)/k;
    end
end

%----初始高度场----
scrsz=get(0,'ScreenSize');
figure1=figure('Position',[0 30 scrsz(3) scrsz(4)]-80);
m_proj('Mercator','longitudes',[60 170],'latitudes',[20 75])
m_coast;
hold on
[lon2,lat2]=m_ll2xy(lon,lat);
contour(lon2,lat2,z0,5180:40:5880,'k','ShowText','on','LineWidth',2)
title('500hPa,height(gpm) UTC19730429 0000','FontSize',20)
p=0:0:0;
set(gca,'xtick',p);
set(gca,'ytick',p); 
set(gca,'xcolor',[1,1,1]);
set(gca,'ycolor',[1,1,1]);
saveas(gcf,'z0.png')
%----初始风场----
scrsz=get(0,'ScreenSize');
figure2=figure('Position',[0 30 scrsz(3) scrsz(4)]-80);
m_proj('Mercator','longitudes',[60 170],'latitudes',[20 75])
m_coast;
hold on
[lon2,lat2]=m_ll2xy(lon,lat);
quiver(lon2,lat2,u0,v0,'k','LineWidth',2)
title('500hPa,wind(m/s) UTC19730429 0000','FontSize',20)
p=0:0:0;
set(gca,'xtick',p);
set(gca,'ytick',p); 
set(gca,'xcolor',[1,1,1]);
set(gca,'ycolor',[1,1,1]);
saveas(gcf,'wind0.png')
%----预报24小时高度场----
scrsz=get(0,'ScreenSize');
figure3=figure('Position',[0 30 scrsz(3) scrsz(4)]-80);
m_proj('Mercator','longitudes',[60 170],'latitudes',[20 75])
m_coast;
hold on
[lon2,lat2]=m_ll2xy(lon,lat);
contour(lon2,lat2,z(:,:,144),5180:40:5880,'k','ShowText','on','LineWidth',2)
title('500hPa,height(gpm) UTC19730429 0024','FontSize',20)
p=0:0:0;
set(gca,'xtick',p);
set(gca,'ytick',p); 
set(gca,'xcolor',[1,1,1]);
set(gca,'ycolor',[1,1,1]);
saveas(gcf,'z024.png')
%----预报24小时风场----
scrsz=get(0,'ScreenSize');
figure2=figure('Position',[0 30 scrsz(3) scrsz(4)]-80);
m_proj('Mercator','longitudes',[60 170],'latitudes',[20 75])
m_coast;
hold on
[lon2,lat2]=m_ll2xy(lon,lat);
quiver(lon2,lat2,u(:,:,144),v(:,:,144),'k','LineWidth',2)
title('500hPa,wind(m/s) UTC19730429 0024','FontSize',20)
p=0:0:0;
set(gca,'xtick',p);
set(gca,'ytick',p); 
set(gca,'xcolor',[1,1,1]);
set(gca,'ycolor',[1,1,1]);
saveas(gcf,'wind024.png')

%----预报day天后的风场----
scrsz=get(0,'ScreenSize');
figure2=figure('Position',[0 30 scrsz(3) scrsz(4)]-80);
m_proj('Mercator','longitudes',[60 170],'latitudes',[20 75])
m_coast;
hold on
[lon2,lat2]=m_ll2xy(lon,lat);
quiver(lon2,lat2,u(:,:,day*144),v(:,:,day*144),'k','LineWidth',2)
title(append('500hPa,wind(m/s) UTC19730429 0',num2str(day*24)),'FontSize',20)
p=0:0:0;
set(gca,'xtick',p);
set(gca,'ytick',p); 
set(gca,'xcolor',[1,1,1]);
set(gca,'ycolor',[1,1,1]);
saveas(gcf,append('wind',num2str(day*24),'.png'))