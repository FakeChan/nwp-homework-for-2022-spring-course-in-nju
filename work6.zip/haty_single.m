function bar=haty_single(a)

    global d
    n=size(a);
    bar=zeros(n);
    for j=2:n(2)-1
        bar(:,j)=(a(:,j+1)-a(:,j-1))/(2*d);
    end
end