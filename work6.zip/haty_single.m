function bar=haty_single(a)
    bar2=hatx_single(a');
    bar=bar2';
end